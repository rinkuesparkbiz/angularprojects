<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Image extends Model
{
    use HasFactory;
    protected $table = 'images';
    protected $guarded = array();
    protected $appends = ['img_url'];



    public function storeData($input)
    {
        return static::create($input);
    }

    public function getImgUrlAttribute($value)
    {
      // dd($this->name);
        if (!empty($this->name)) {
  	        return asset('post/'.$this->name);
  	    } else {
  	        return asset('post/no-image.jpg');
  	    }
    }
    public function getIsAdminAttribute($value)
    {
        if ($value) {
  	        return asset('post/'.$value);
  	    } else {
  	        return asset('post/no-image.jpg');
  	    }
        return $this->attributes['img_url'] === 'yes';
    }
    public function getNameAttribute($value)
	{

	    if ($value) {
	        return asset('post/'.$value);
	    } else {
	        return asset('post/no-image.jpg');
	    }
	}
}
