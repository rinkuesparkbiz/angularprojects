<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator,Redirect,Response,File;
Use App\Models\Image;
Use App\Models\Post;
Use App\Models\Like;
Use App\Models\Comment;
Use App\Models\Reply;
Use App\Models\User;
use Illuminate\Support\Str;
use Flugg\Responder\Responder;
use Auth;
use Hash;

class ApiController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

  public function login (Request $request) {
     $validator = Validator::make($request->all(), [
       'email' => 'required|string|email|max:255',
       'password' => 'required|string|min:6|max:10',
     ]);
     if ($validator->fails())
     {
       // return response(['errors'=>$validator->errors()->all()], 422);
         return response(['errors'=>$validator->errors()->messages()], 422);
     }
     $user = User::where('email', $request->email)->first();
     if ($user) {
         if (Hash::check($request->password, $user->password)) {
             $token = $user->createToken('Laravel Password Grant Client')->accessToken;
             // return $this->success([
             //     'token' => auth()->user()->createToken('API Token')->plainTextToken
             // ]);
             $response = ['status'=>true,'token' => $token,'user'=>$user,'message'=>'Login successfully'];

             return response()->json($response, 200);
         } else {
             $response = ['status'=>false,"message" => "Password Mismatch"];
             return response($response, 200);
         }
     } else {
         $response = ['status'=>false,"message" =>'User does not exist'];
         return response($response, 200);
     }
 }

 public function register (Request $request) {

    $validator = Validator::make($request->all(), [
        'name' => 'required|string|max:255',
        'email' => 'required|string|email|max:255|unique:users',
        'password' => 'required|string|min:6|confirmed',
    ]);
    if ($validator->fails())
    {
        return response(['errors'=>$validator->errors()->all()], 422);
    }
    $request['password']=Hash::make($request['password']);
    $request['remember_token'] = Str::random(10);
    $user = User::create($request->toArray());
    $token = $user->createToken('Laravel Password Grant Client')->accessToken;
    $response = ['token' => $token,'user'=>$user];
    return response($response, 200);
}


 public function logout (Request $request) {

   $token = $request->user()->token();
    $token->revoke();
    $response = ['message' => 'You have been successfully logged out!'];
    return response($response, 200);
}

    public function index()
    {
        $posts = Post::with('Images')->get();
        return view('home',compact('posts'));
    }
    public function ViewPost($id, $user_id)
    {
        $row = Post::with('Images','Comments.User','Comments.Replies.User','Comments.Replies.ReplyCommentUser')->find($id);
        $likeCount = Like::where('post_id',$id)->count();
        $hasLike = Like::where('user_id',$user_id)->where('post_id',$id)->count();
        $data = [
          'post'=>$row,
          'like_count'=>$likeCount,
          'has_like'=>$hasLike
        ];
        return response()->json($data, 200);
    }
    public function PostLike(Request $request, $post_id, $user_id)
    {
        if ($request->isMethod('get')) {
            if (!empty($post_id) && !empty($user_id)) {
                $hasLike = Like::where('user_id',$user_id)->where('post_id',$post_id)->count();
                if ($hasLike == 0) {
                    $input['user_id'] = $user_id;
                    $input['post_id'] = $post_id;
                    Like::create($input);
                }
                return 1;
            }
        }
    }
    public function PostComment(Request $request)
    {
        if ($request->isMethod('post')) {
            request()->validate([
                'comment' => 'required',
                'image' => 'mimes:jpeg,jpg,png,gif'
            ]);
            if($request->hasfile('file')) {
                $image = $request->file('file');
                $imageName = time().rand(0, 1000).pathinfo($image->getClientOriginalName(), PATHINFO_FILENAME);
                $imageName = $imageName.'.'.$image->getClientOriginalExtension();
                $image->move(public_path('comment'),$imageName);
                $input['image'] = $imageName;
            }
            if (!empty($request->input('id'))) {
                $input['user_id'] = $request->input('user_id');
                $input['post_id'] = $request->input('id');
                $input['comment'] = $request->input('comment');
                $res = Comment::create($input);
                if ($res) {
                    $response = array('success' => 'Comment Added Successfully.');
                } else {
                    $response = array('fail' => 'CommOpps! Somthing Went Wrong.');
                }
            }
            return response()->json($response, 200);
        }
    }
    public function CommentReply(Request $request)
    {
        if ($request->isMethod('post')) {
            request()->validate([
                'comment' => 'required',
                'image' => 'mimes:jpeg,jpg,png,gif'
            ]);
            if($request->hasfile('file')) {
                $image = $request->file('file');
                $imageName = time().rand(0, 1000).pathinfo($image->getClientOriginalName(), PATHINFO_FILENAME);
                $imageName = $imageName.'.'.$image->getClientOriginalExtension();
                $image->move(public_path('comment'),$imageName);
                $input['image'] = $imageName;
            }
            $comment = Comment::find($request->input('comment_id'));
            $reply = Reply::find($request->input('reply_id'));
            if (!empty($comment)) {
                $input['user_id'] = $request->input('user_id');
                $input['comment_user_id'] = ($request->input('type')==1) ? $comment->user_id : $reply->user_id;
                $input['type'] = (int)$request->input('type');
                $input['comment_id'] = $comment->id;
                $input['reply_comment_id'] = (int)$request->input('reply_id');
                $input['comment'] = $request->input('comment');
                $res = Reply::create($input);
                if ($res) {
                  $response = array('success' => 'Comment Added Successfully.');
                } else {
                  $response = array('fail' => 'CommOpps! Somthing Went Wrong.');
                }
            }
            return response()->json($response, 200);
        }
    }
    public function DeleteComment(Request $request)
    {
      // return response()->json($request->all(), 200);
        $type = $request->input('type');
        $id = $request->input('id');
        if ($type == 1) {
            $res = Comment::destroy($id);
        }else{
            $res = Reply::find($id);
            Reply::where('reply_comment_id', $res->reply_comment_id)->delete();
            $res->delete();
        }
        if ($res) {
          $response = array('success' => 'Comment Added Successfully.');
        } else {
          $response = array('fail' => 'CommOpps! Somthing Went Wrong.');
        }
        return response()->json($response, 200);
    }
    public function PostList()
    {
        $posts = Post::with('Images')->orderBy('id','ASC')->get();
        return response()->json($posts, 200);

    }
    public function MyPosts($user_id)
    {
        $posts = Post::with('Images')->where('user_id',$user_id)->get();
        return response()->json($posts, 200);

    }
    public function editPost($id)
    {
        $row = Post::with('Images')->find($id);
        return response()->json($row, 200);
    }

    public function StorePost(Request $request, $user_id)
    {



        $validator = Validator::make($request->all(), [
          'description' => 'required',
          'files.*' => 'mimes:mp4,jpeg,jpg,png,gif'
        ]);
        // dd($validator);
        if ($validator->fails())
        {
          // return response(['errors'=>$validator->errors()->all()], 422);
            return response(['errors'=>$validator->errors()->messages()], 422);
        }
        if ($request->input('description')) {
            if (!empty($request->input('id'))) {
                $post = Post::find($request->input('id'));
                $post->description = $request->input('description');
                $post->save();
                $msg = 'Post Updated Successfully';
            }else{
                $post = Post::create(['user_id'=>$user_id, 'description'=>$request->input('description')]);
                $msg = 'Post Added Successfully';
            }
        }
        if($request->hasfile('files')) {
            foreach($request->file('files') as $image)
            {
                // $image = $request->file('files');
                $imageName = time().rand(0, 1000).pathinfo($image->getClientOriginalName(), PATHINFO_FILENAME);
                $imageName = $imageName.'.'.$image->getClientOriginalExtension();
                $image->move(public_path('post'),$imageName);
                $input['post_id'] = $post->id;
                $input['name'] = $imageName;
                Image::create($input);
            }
        }
        return response()->json($post, 200);
    }
    public function DeleteImage(Request $request)
    {

      if (!empty($request->input('id'))) {
        $id = $request->input('id');
        $res = Image::find($id);
        $path = public_path().'/post/'.basename($res->name);
        if(File::exists($path)){
              File::delete($path);
        }
        $res->delete();
        if ($res) {
          $response = array('success' => 'Image Delete Successfully.');
        } else {
          $response = array('fail' => 'Opps! Somthing Went Wrong.');
        }
        return response()->json($response, 200);
      }

    }
}
