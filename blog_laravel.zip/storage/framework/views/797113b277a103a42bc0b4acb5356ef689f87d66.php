<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <a href="<?php echo e(route('AddPost')); ?>" class="btn btn-primary mb-5 rounded-lg">Add Post</a>
            <a href="<?php echo e(route('PostList')); ?>" class="btn btn-primary mb-5 rounded-lg">Post List</a>
        </div>
        <?php if($posts->count() > 0): ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card">
                    <div class="img-post owl-carousel owl-theme">
                        <?php if($row->Images->count() > 0): ?>
                    <?php $__currentLoopData = $row->Images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $ext = pathinfo($image->name, PATHINFO_EXTENSION); ?>
                    <?php if($ext == 'mp4'): ?>
                    <video class="card-img img-fluid item" src="<?php echo e($image->name); ?>" controls></video>
                    <?php else: ?>
                    <img class="card-img-top img-fluid item" src="<?php echo e($image->name); ?>" alt="First slide">
                    <?php endif; ?>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    <?php else: ?>
                    <img class="card-img-top img-fluid item" src="<?php echo e(asset('post/no-image.jpg')); ?>" alt="First slide">
                    <?php endif; ?>
                    </div>
                    
                  <div class="card-body">
                    <p class="card-text"><?php echo e($row->description); ?></p>
                    <a href="<?php echo e(route('ViewPost',$row->id)); ?>" class="btn btn-outline-secondary btn-sm float-md-right">Read More</a>
                  </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>

                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<script>
    jQuery(document).ready(function($) {
      $('.img-post').owlCarousel({
        items: 1,
        animateOut: 'fadeOut',
        loop: false,
        margin: 10,
      });
      $('.custom1').owlCarousel({
        animateOut: 'slideOutDown',
        animateIn: 'flipInX',
        items: 1,
        margin: 30,
        stagePadding: 30,
        smartSpeed: 450
      });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/blog/resources/views/home.blade.php ENDPATH**/ ?>