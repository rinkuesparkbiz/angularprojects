<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">

        <div class="col-12">
          <a href="<?php echo e(route('PostList')); ?>" class="btn btn-primary mb-5 rounded-lg">Post List</a>
            <div class="card">
              <?php if($message = Session::get('success')): ?> 
                  <div class="alert alert-success alert-block"> 
                      <button type="button" class="close" data-dismiss="alert">×</button> 
                      <strong><?php echo e($message); ?></strong> 
                  </div>
              <?php endif; ?> 
               <?php if($message = Session::get('fail')): ?> 
                  <div class="alert alert-danger alert-block"> 
                      <button type="button" class="close" data-dismiss="alert">×</button> 
                      <strong><?php echo e($message); ?></strong> 
                  </div>
              <?php endif; ?> 
              <?php if(count($errors) > 0): ?>
                  <div class="alert alert-danger">
                      <strong>Whoops!</strong> There were some problems with your input.<br><br>
                      <ul>
                          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                  </div>
              <?php endif; ?> 

              <form name="StorePost" action="<?php echo e(route('StorePost')); ?>" class="form-horizontal" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e(@$row->id); ?>">
                  <div class="form-group col-sm-12">
                      <label> <strong>Description</strong></label>
                      <textarea class="form-control" rows="5" name="description" id="description" minlength="20" maxlength="255" required><?php echo e(@$row->description); ?></textarea>
                      <span class="help-block"></span>
                  </div>
                  <div class="form-group col-sm-12">
                    <label> <strong>Images Upload (Multiple)</strong></label>
                      <input type="file" class="form-control-file" name="images[]" multiple>                   
                  </div>
                  <?php if($row->Images->count() > 0): ?>
                  <div class="col-sm-12">
                    <div class="row">
                      <?php $__currentLoopData = $row->Images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php $ext = pathinfo($row->name, PATHINFO_EXTENSION); ?>
                      <div class="col-sm-4">
                        <div class="card">
                          <?php if($ext == 'mp4'): ?>
                          <video width="320" height="240" src="<?php echo e($row->name); ?>" controls></video>
                          <?php else: ?>
                          <img class="card-img-top" src="<?php echo e($row->name); ?>" alt="Card image" style="width:100%">
                          <?php endif; ?>
                          <div class="card-body text-right">
                            <a href="<?php echo e(route('DeletePost',$row->id)); ?>" class="btn btn-danger">Delete</a>
                          </div>
                        </div>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </div>
                  </div>
                   <?php endif; ?> 
                  
                  <div class="form-group col-sm-12">
                   <button type="submit" class="btn btn-primary" value="submit">Save
                   </button>
                  </div>
              </form>
            </div>
       </div> 
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/blog/resources/views/add-post.blade.php ENDPATH**/ ?>