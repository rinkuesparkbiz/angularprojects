<?php $__env->startSection('content'); ?>
<div class="container">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
<div id="main-content" class="blog-page">
        <div class="container">
            <div class="row clearfix">
                <div class="col-lg-8 col-md-12 left-box">
                    <?php if($message = Session::get('success')): ?> 
                      <div class="alert alert-success alert-block"> 
                          <button type="button" class="close" data-dismiss="alert">×</button> 
                          <strong><?php echo e($message); ?></strong> 
                      </div>
                  <?php endif; ?> 
                   <?php if($message = Session::get('fail')): ?> 
                      <div class="alert alert-danger alert-block"> 
                          <button type="button" class="close" data-dismiss="alert">×</button> 
                          <strong><?php echo e($message); ?></strong> 
                      </div>
                  <?php endif; ?> 
                    <?php if(count($errors) > 0): ?>
                      <div class="alert alert-danger">
                          <strong>Whoops!</strong> There were some problems with your input.<br><br>
                          <ul>
                              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li><?php echo e($error); ?></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>
                      </div>
                  <?php endif; ?>
                    <div class="card single_post">
                        <div class="body">
                            <div class="img-post owl-carousel owl-theme">
                                <?php if($row->Images->count() > 0): ?>
                                <?php $__currentLoopData = $row->Images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $ext = pathinfo($image->name, PATHINFO_EXTENSION); ?>
                                <?php if($ext == 'mp4'): ?>
                                <video class="d-block img-fluid item" src="<?php echo e($image->name); ?>" controls></video>
                                <?php else: ?>
                                <img class="d-block img-fluid item" src="<?php echo e($image->name); ?>" alt="First slide">
                                <?php endif; ?>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                <?php else: ?>
                                <img class="d-block img-fluid item" src="https://via.placeholder.com/800x280/87CEFA/000000" alt="First slide">
                                <?php endif; ?>
                            </div>
                            <button class="btn btn-primary rounded-lg" <?php if($hasLike == 0): ?> onclick="PostLike(<?php echo e($row->id); ?>);" <?php endif; ?>><i class="fa fa-thumbs-up"></i>     
                             <span id="likeCount"><?php echo e($likeCount); ?></span></button>
                            <button class="btn btn-primary rounded-lg"><i class="fa fa-comments"></i> Comment</button>
                            <p><?php echo e($row->description); ?></p>
                        </div>                        
                    </div>
                    <div class="card">
                            <div class="header">
                                <h2>Comments</h2>
                            </div>
                            <div class="body">
                                <ul class="comment-reply list-unstyled">
                                    <?php if($row->Comments->count() > 0): ?>
                                        <?php $__currentLoopData = $row->Comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="row maincomment clearfix">
                                            <div class="icon-box col-md-2 col-4"><img class="img-fluid img-thumbnail" src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="Awesome Image"></div>
                                            <div class="text-box col-md-10 col-8 p-l-0 p-r0">
                                                <h5 class="m-b-0"><?php echo e($comment->getUserName($comment->user_id)); ?> </h5>
                                                <p><?php echo e($comment->comment); ?></p>
                                                <?php if(!empty($comment->image)): ?>
                                                <div class="image"><img class="img-fluid img-thumbnail" width="100" src="<?php echo e($comment->image); ?>" alt="Awesome Image"></div>
                                                <?php endif; ?>
                                                <ul class="list-inline">
                                                    <li><a href="javascript:void(0);"><?php echo e(date('D m Y', strtotime($comment->created_at))); ?></a></li>
                                                    <li><a href="javascript:void(0);" class="btn btn-primary btn-sm rounded-lg" onclick="commentReply(<?php echo e($comment->id); ?>, <?php echo e($comment->id); ?>, 1, this);">Reply</a></li>
                                                     <?php if($comment->user_id == Auth::id()): ?><li><a href="<?php echo e(route('DeleteComment',['id'=>$comment->id,'type'=>1])); ?>" class="btn btn-primary btn-sm rounded-lg">Delete</a></li> <?php endif; ?>
                                                </ul>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="row">
                                                     <div class="commentReplySection col-md-12 col-12 mt-5">
                                                         <ul class="comment-reply">
                                                             <?php if($comment->Replies->count() > 0): ?>
                                                                <?php $__currentLoopData = $comment->Replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li class="row mainReplyComment clearfix">
                                                                    <div class="icon-box col-md-2 col-4"><img class="img-fluid img-thumbnail" src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="Awesome Image"></div>
                                                                    <div class="text-box col-md-10 col-8 p-l-0 p-r0">
                                                                        <h5 class="m-b-0"><?php echo e($reply->getUserName($reply->user_id)); ?> </h5>
                                                                        <p><a href="javascript:void(0);">@ <?php echo e($reply->getUserName($reply->comment_user_id)); ?></a>  <?php echo e($reply->comment); ?></p>
                                                                        <?php if(!empty($reply->image)): ?>
                                                                        <div class="image"><img class="img-fluid img-thumbnail" width="100" src="<?php echo e($reply->image); ?>" alt="Awesome Image"></div>
                                                                        <?php endif; ?>
                                                                        <ul class="list-inline">
                                                                            <li><a href="javascript:void(0);"><?php echo e(date('D m Y', strtotime($reply->created_at))); ?></a></li>
                                                                            <li><a href="javascript:void(0);" class="btn btn-primary btn-sm rounded-lg" onclick="commentReply(<?php echo e($comment->id); ?>,<?php echo e($reply->id); ?>, 2, this);">Reply</a></li>
                                                                            <?php if($reply->user_id == Auth::id()): ?> <li><a href="<?php echo e(route('DeleteComment',['id'=>$reply->id,'type'=>2])); ?>" class="btn btn-primary btn-sm rounded-lg">Delete</a></li> <?php endif; ?>
                                                                        </ul>
                                                                    </div>
                                                                </li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                         </ul>
                                                     </div>
                                                </div>
                                            </div>
                                            <div class="commentSection col-md-12 col-12 mt-5" style="display: none;"></div> 

                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </ul>                                        
                            </div>
                        </div>
                        <div class="card">
                            <div class="header">
                                <h2>Leave a comment</h2>
                            </div>
                            <div class="body">
                                <div class="comment-form">
                                    <form name="PostComment" action="<?php echo e(route('PostComment',$row->id)); ?>" class="form-horizontal row clearfix" method="post" enctype="multipart/form-data">
                                         <?php echo csrf_field(); ?>
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <textarea rows="4" class="form-control no-resize" name="comment" placeholder="Please type what you want..." required></textarea>
                                            </div>
                                            <div class="form-group col-sm-12">
                                                <label> <strong>Images</strong></label>
                                                  <input type="file" class="form-control-file" name="image">                   
                                              </div>
                                            <button type="submit" class="btn btn-block btn-primary" value="submit">SUBMIT</button>
                                        </div>                                
                                    </form>
                                </div>
                            </div>
                        </div>
                </div>
                <div class="col-lg-4 col-md-12 right-box">
                    <div class="card">
                        <div class="header">
                            <h2>Popular Posts</h2>                        
                        </div>
                        <!--  -->
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<div id="commentForm" style="display: none;">
    <div class="comment-form">
        <form name="CommentReply" action="<?php echo e(route('CommentReply',$row->id)); ?>" class="form-horizontal" method="post" enctype="multipart/form-data">
             <?php echo csrf_field(); ?>
             <input type="hidden" name="comment_id" class="comment_id" value="">
             <input type="hidden" name="reply_id" class="reply_id" value="">
             <input type="hidden" name="type" class="comment_type" value="">
            <div class="col-sm-12">
                <div class="form-group">
                    <textarea rows="4" class="form-control no-resize" name="comment" placeholder="Please type what you want..." required></textarea>
                </div>
                <div class="form-group col-sm-12">
                    <label> <strong>Images</strong></label>
                      <input type="file" class="form-control-file" name="image">                   
                  </div>
                <button type="submit" class="btn btn-block btn-primary" value="submit">SUBMIT</button>
            </div>                                
        </form>
    </div>
</div>

<script>
            jQuery(document).ready(function($) {
              $('.img-post').owlCarousel({
                items: 1,
                animateOut: 'fadeOut',
                loop: false,
                margin: 10,
              });
              $('.custom1').owlCarousel({
                animateOut: 'slideOutDown',
                animateIn: 'flipInX',
                items: 1,
                margin: 30,
                stagePadding: 30,
                smartSpeed: 450
              });
            });
function PostLike(id) {
    jQuery.ajax({
      type: "POST",
      dataType : "JSON",
      url: "<?php echo route('PostLike'); ?>",
      data:{'id':id},
      success: function(data)
      {
        var like = '<?php echo e($likeCount); ?>';
        like = parseInt(like)+1;
        $('#likeCount').text(like);
      },
      error: function(error)
      {
          alert("Oops Something goes Wrong.");
      }
    });
}
function commentReply(id, reply_id, type, thisEvent) {
    $('#commentForm').find('.comment_id').val(id);
    $('#commentForm').find('.reply_id').val(reply_id);
    $('#commentForm').find('.comment_type').val(type);
    var formHtml = $('#commentForm').html();
    if ($(thisEvent).hasClass('active')) {
        $(thisEvent).removeClass('active');
        $(thisEvent).closest('.maincomment').find('.commentSection').slideUp();
        $(thisEvent).closest('.maincomment').find('.commentSection .comment-form').remove();
    }else{
        $('.maincomment').find('.list-inline li a').removeClass('active');
        $('.maincomment').find('.commentSection').slideUp();

        $('.maincomment').find('.commentSection .comment-form').remove();
        setTimeout(function(){ 
             $(thisEvent).closest('.maincomment').find('.commentSection .comment-form').remove();
            $(thisEvent).closest('.maincomment').find('.commentSection').append(formHtml);
            $(thisEvent).addClass('active');
            $(thisEvent).closest('.maincomment').find('.commentSection').slideDown();
        }, 100);
       
        
    }
    
    // jQuery.ajax({
    //   type: "POST",
    //   dataType : "JSON",
    //   url: "<?php echo route('PostLike'); ?>",
    //   data:{'id':id},
    //   success: function(data)
    //   {
    //     var like = '<?php echo e($likeCount); ?>';
    //     like = parseInt(like)+1;
    //     $('#likeCount').text(like);
    //   },
    //   error: function(error)
    //   {
    //       alert("Oops Something goes Wrong.");
    //   }
    // });
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/blog/resources/views/post.blade.php ENDPATH**/ ?>