<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});



Route::middleware('auth:api')->group(function () {
  Route::get('/getPosts', [App\Http\Controllers\ApiController::class, 'PostList']);


  Route::get('/getMyPosts/{user_id}', [App\Http\Controllers\ApiController::class, 'MyPosts']);
  Route::post('/storePost/{user_id}', [App\Http\Controllers\ApiController::class, 'StorePost']);
  Route::get('/viewPost/{id}/{user_id}', [App\Http\Controllers\ApiController::class, 'ViewPost']);
  Route::get('/editPost/{id}', [App\Http\Controllers\ApiController::class, 'editPost']);
  Route::get('/postLike/{post_id}/{user_id}', [App\Http\Controllers\ApiController::class, 'PostLike']);
  Route::post('/postComment', [App\Http\Controllers\ApiController::class, 'PostComment']);
  Route::post('/commentReply', [App\Http\Controllers\ApiController::class, 'CommentReply']);
  Route::post('/deleteComment', [App\Http\Controllers\ApiController::class, 'DeleteComment']);
  Route::post('/deleteImage', [App\Http\Controllers\ApiController::class, 'DeleteImage']);
});

Route::group(['middleware' => ['cors', 'json.response']], function () {

    // ...

    // public routes
    Route::post('/login', [App\Http\Controllers\ApiController::class, 'login']);
    Route::post('/register', [App\Http\Controllers\ApiController::class, 'register']);

    // ...

});
Route::middleware('auth:api')->group(function () {
    // our routes to be protected will go in here
    Route::post('/logout', [App\Http\Controllers\ApiController::class, 'logout']);

});
